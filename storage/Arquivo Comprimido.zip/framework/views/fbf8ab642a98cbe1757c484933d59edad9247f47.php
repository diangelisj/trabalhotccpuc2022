<?php $__env->startSection('content'); ?>
    <h1>Atualizar Produto</h1>

    <form action="<?php echo e(route('admin.products.update',['product'=>$product->id])); ?>" method="post" enctype="multipart/form-data">

        <?php echo csrf_field(); ?>
        <?php echo method_field("PUT"); ?>
        <div class="form-group">

            <label>Produto</label>
            <input type="text" name="name" class="form-control" value="<?php echo e($product->name); ?>">

        </div>


        <div class="form-group">

            <label>Descrição</label>
            <input type="text" name="description"  class="form-control" value="<?php echo e($product->description); ?>">


        </div>
        <div class="form-group">

            <label>Conteúdo</label>
            <textarea name="body" id="" cols="30" rows="10" class="form-control"><?php echo e($product->body); ?></textarea>

        </div>

        <div class="form-group">
            <label>Preço</label>
            <input type="text" name="price"  class="form-control" value="<?php echo e($product->price); ?>">


        </div>
        <div class="form-group">
            <label>Categorias</label>
            <select name="categories[]" id=""  multiple>

                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"

                    <?php if($product->categories->contains($category)): ?> selected <?php endif; ?>
                    ><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <select>
        </div>

        <div class="form-group">
            <label for=""> Fotos do Produto</label>
            <input type="file" name="photos[]" class="form-control <?php $__errorArgs = ['photos.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" multiple>
                <?php $__errorArgs = ['photos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>


        </div>



        <div>
            <button type="submit" class="btn btn-lg  btn-success">Ciar Produto</button>
        </div>

    </form>

    <hr>
<div class="row">

    <?php $__currentLoopData = $product->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-4">
            <img src="<?php echo e(asset('storage/'.$photo->image)); ?>" alt="" class="img-fluid">
            <form action="<?php echo e(route('admin.photo.remove')); ?>" method="post">

                <?php echo csrf_field(); ?>

                <input type="hidden" name="photoName" value="<?php echo e($photo->image); ?>">
                <button type="submit" class="btn btn-lg btn-danger">REMOVER</button>
            </form>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/dev/Sites/puc-pos-tcc/resources/views/admin/products/edit.blade.php ENDPATH**/ ?>