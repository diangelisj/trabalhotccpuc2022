<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Marketplace L6</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
    <style>
        .front.row {
    margin-bottom: 40px;
        }
    </style>
</head>
<body>

<div class="container nav-bar-style">
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">

        <a class="navbar-brand" href="#">
            <img src="<?php echo e('assets/img/01-puc-minas-logo.png'); ?>" alt="" width="150" height="50">
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('home')); ?>">HOME</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        CATEGORIAS
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">

                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a class="dropdown-item" href="#"><?php echo e($category->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('home')); ?>">HOME</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.products.create')); ?>">CADASTRAR PRODUTO</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('login')); ?>">ACESSAR</a>
                </li>


            </ul>
        </div>
    </div>
</nav>
    <?php if(auth()->guard()->check()): ?>
    <?php echo e(auth()->user()->name); ?>

    <a class="nav-link" href="#" onclick="event.preventDefault();
    document.querySelector('form.logout').submit(); ">Sair</a>

    <form action="<?php echo e(route('logout')); ?>" class="logout" method="POST" style="display:none;">
        <?php echo csrf_field(); ?>
    </form>
        <?php endif; ?>
</div>
<!--
<nav class="navbar navbar-expand-lg navbar-light bg-light" style="margin-bottom: 40px;">

    <a class="navbar-brand" href="<?php echo e(route('home')); ?>">L6</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">

        <ul class="navbar-nav mr-auto">
            <li class="nav-item <?php if(request()->is('home')): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('home')); ?>">Home 2<span class="sr-only">(current)</span></a>
            </li>
        </ul>

<?php if(auth()->guard()->check()): ?>
    <ul class="navbar-nav mr-auto">
        <li class="nav-item <?php if(request()->is('admin/stores*')): ?> active <?php endif; ?>">
            <a class="nav-link" href="<?php echo e(route('admin.stores.index')); ?>">Lojas <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item <?php if(request()->is('admin/products*')): ?> active <?php endif; ?>">
            <a class="nav-link" href="<?php echo e(route('admin.products.index')); ?>">Produtos</a>
        </li>
        <li class="nav-item <?php if(request()->is('admin/categories*')): ?> active <?php endif; ?>">
            <a class="nav-link" href="<?php echo e(route('admin.categories.index')); ?>">Categorias</a>
        </li>
    </ul>

    <div class="my-2 my-lg-0">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="#" onclick="event.preventDefault();
                                                                  document.querySelector('form.logout').submit(); ">Sair</a>

                <form action="<?php echo e(route('logout')); ?>" class="logout" method="POST" style="display:none;">
                    <?php echo csrf_field(); ?>
                </form>
            </li>
            <li class="nav-item">
                <span class="nav-link"><?php echo e(auth()->user()->name); ?></span>
            </li>
            <?php endif; ?>
         <a href="<?php echo e(route('cart.index')); ?>" class="nav-link">
                <?php if(session()->has('cart')): ?>
                 <span class="badge-danger"><?php echo e(count(session()->get('cart'))); ?></span>

                <!-- Contanto os itens do carrinho - inicio  ------------------>
                <span class="badge-danger"><?php echo e(array_sum(array_column(session()->get('cart'),'amount'))); ?></span>
               <!------------------ Contanto os itens do carrinho - final -------------------
                <span>

                </span>
                <?php endif; ?>
            Carrinho
            <i class="fa fa-shopping-cart"></i>
         </a>

        </ul>
    </div>


    </div>
    </nav>


-->



    <div class="container">
        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </br>
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <?php echo $__env->yieldContent('scripts'); ?>
    </body>
    </html><?php /**PATH /Users/dev/Sites/puc-pos-tcc/resources/views/admin/layouts/front.blade.php ENDPATH**/ ?>