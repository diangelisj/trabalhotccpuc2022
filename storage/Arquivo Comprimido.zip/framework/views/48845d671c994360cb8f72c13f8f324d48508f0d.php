
<div class="container">
   
    <hr>
  <p>Desenvolvido como trabalho de conclusão de curso PUC Minas</p>
  <p>Pós Graduação Engenharia de Software 2021/2022</p>

</div>

<?php /**PATH /Users/dev/Sites/puc-pos-tcc/resources/views/layouts/footer.blade.php ENDPATH**/ ?>