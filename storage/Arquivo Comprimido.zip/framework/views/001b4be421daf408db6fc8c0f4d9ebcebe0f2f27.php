<?php $__env->startSection('content'); ?>


    <?php if(!$store): ?>
    <a href="<?php echo e(route('admin.stores.create')); ?>" class="btn btn-lg btn-success">Criar loja</a>
    <?php else: ?>
    <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Loja</th>
                    <th>Proprietário</th>
                    <th>Total de produtos</th>
                    <th>Ações</th>
                </tr>

            </thead>

            <tbody>


                <tr>
                    <th><?php echo e($store->id); ?></th>
                    <th><?php echo e($store->name); ?></th>
                    <th><?php echo e($store->products->count()); ?></th>
                    <th>
                        <div class="btn-group">

                            <a href="<?php echo e(route('admin.stores.edit',['store'=>$store->id])); ?>" class="btn btn-sm btn-primary">Editar</a>
                            <form action="<?php echo e(route('admin.stores.destroy',['store'=>$store->id])); ?>"method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field("DELETE"); ?>
                                <button type="submit" class="btn btn-sm btn-danger">Remover</button>
                            </form>
                        </div>

                    </th>
                </tr>



            </tbody>

        </table>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/dev/Sites/puc-pos-tcc/resources/views/admin/stores/index.blade.php ENDPATH**/ ?>