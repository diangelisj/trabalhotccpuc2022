<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <h2>Carinho de compras</h2>
            <hr>
        </div>

        <div class="col-12">

            <?php if($cart): ?>
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <td>Produto</td>
                        <td>Preço</td>
                        <td>Quantidade</td>
                        <td>Subtotal</td>
                        <td>Ações</td>
                    </tr>
                    </thead>

                    <tbody>

                    <?php  $total =0;   ?>

                    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($c['name']); ?></td>
                            <td>R$: <?php echo e(number_format(($c['price']),2,',','.')); ?></td>
                            <td><?php echo e($c['amount']); ?></td>
                            <?php
                                $subtotal = $c['price'] * $c['amount'] ;
                                  $total += $subtotal;
                            ?>
                            <td>R$: <?php echo e(number_format(($c['amount']*$c['price']),2,',','.')); ?></td>
                            <td>
                                <a href="<?php echo e(route('cart.remove',['slug'=>$c['slug']])); ?>" class="btn btn-danger">REMOVER</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td colspan="3">Total: </td>
                        <td colspan="2">R$: <?php echo e(number_format($total,2,',','.')); ?></td>
                    </tr>
                    </tbody>
                </table>
                <div class="col-md-12">
                    <a href="<?php echo e(route('cart.cancel')); ?>" class="btn  btn-danger float-left">Cancelar Compra</a>
                    <a href="<?php echo e(route('checkout.index')); ?>" class="btn btn-success float-right">Concluir Compra</a>

                </div>

            <?php else: ?>
                <div class="alert alert-warning">
                    Carrinho vazio!
                </div>

            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/dev/mp6/resources/views/cart.blade.php ENDPATH**/ ?>