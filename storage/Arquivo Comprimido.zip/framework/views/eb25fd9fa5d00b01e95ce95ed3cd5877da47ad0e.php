<?php $__env->startSection('content'); ?>
<h1>Criar Loja</h1>
<form action="<?php echo e(route('admin.stores.update',['store'=>$store->id])); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<?php echo method_field("PUT"); ?>

<div class="form-group">

    <label>Loja</label>
    <input type="text" name="name" class="form-control" value="<?php echo e($store->name); ?>">

</div>
<div class="form-group">

    <label>Descrição</label>
    <input type="text" name="description"  class="form-control" value="<?php echo e($store->description); ?>">


</div>

<div class="form-group">
    <label>Telefone</label>
    <input type="text" name="phone"  class="form-control" value="<?php echo e($store->phone); ?>">


</div>
<div class="form-group">
    <label>Telefone Celular / WhatsApp</label>
    <input type="text" name="mobile_phone"  class="form-control"value="<?php echo e($store->mobile_phone); ?>">


</div>

    <div class="form-group">
        <label for=""> Logo loja</label>
        <p>
        <img src="<?php echo e(asset('storage/'.$store->logo)); ?>" alt="">
        </p>
        <input type="file" name="logo" class="form-control <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
        <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

<div>

</div>


<div>
    <button type="submit" class="btn btn-lg  btn-success">Atualizar Loja</button>
</div>

</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mp6/resources/views/admin/stores/edit.blade.php ENDPATH**/ ?>