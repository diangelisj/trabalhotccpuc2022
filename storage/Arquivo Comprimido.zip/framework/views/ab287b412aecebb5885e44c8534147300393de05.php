<?php $__env->startSection('content'); ?>

    <div class="col-12">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Library</a></li>
                <li class="breadcrumb-item active" aria-current="page">Data</li>
            </ol>
        </nav>
    </div>

    <div class="col-12">
        <div class="col-6">
            <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">

                    <?php if($product->photos->count()): ?>
                        <img src="<?php echo e(asset('storage/'.$product->photos->first()->image)); ?>"  class="card-img-top" alt="">
                        <?php $__currentLoopData = $product->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item active">
                        <img src="..." class="d-block w-100" alt="...">
                    </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <?php else: ?>
                    <img src="https://img0.icarros.com/dbimg/imgnoticia/4/27348_1"  class="card-img-top" alt="" >

                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="row" style="margin-top:20px ">
        <div class="col-6">
            <?php if($product->photos->count()): ?>
                <img src="<?php echo e(asset('storage/'.$product->photos->first()->image)); ?>"  class="card-img-top" alt="">
                <div class="row">
                    <?php $__currentLoopData = $product->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-4">
                            <img src="<?php echo e(asset('storage/'.$photo->image)); ?>"  alt=""  class="img-fluid">
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <img src="<?php echo e(asset('assets/img/no-photo.jpg')); ?>"  class="card-img-top" alt="" >

            <?php endif; ?>

        </div>
            <div class="col-6 fluid">
               <div class="col-md-12">
                   <h2> <?php echo e($product->name); ?></h2>

                   <p> <?php echo e($product->description); ?></p>
                   <h3>RS: <?php echo e(number_format($product->price,'2',',','.')); ?></h3>
                   <span>Loja: <?php echo e($product->store->name); ?></span>
               </div>


                <hr>

        <div class="product-add col-md-12">

            <form action="<?php echo e(route('cart.add')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="product[name]" value="<?php echo e($product->name); ?>">
                <input type="hidden" name="product[price]"value="<?php echo e($product->price); ?>">
                <input type="hidden" name="product[slug]"value="<?php echo e($product->slug); ?>">
                <div class="form-group">
                    <label>Quantidade</label>
                    <input type="number" name="product[amount]" class="form-control col-md-2" value="1">
                </div>
                <button  class="btn btn-danger">Comprar</button>
            </form>
        </div>

    </div>
    </div>
    <hr>
    <div class="row">

        <?php echo e($product->body); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mp6/resources/views/single.blade.php ENDPATH**/ ?>